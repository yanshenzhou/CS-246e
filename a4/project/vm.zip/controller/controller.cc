#include "controller.h"

int Controller::getAction() {
   return action();
};
