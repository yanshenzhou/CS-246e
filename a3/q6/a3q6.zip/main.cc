#include <iostream>
#include <fstream>
#include <string>

#include "re.h"

void processFile(std::istream &f, std::string reg, std::string filen) {
   auto re = CS246E::parseDisjunction(reg);
   std::string s;
   while (getline(f, s)){
      if (CS246E::containsMatch(re.get(), s) == true) { std::cout << filen  << s << std::endl; }
   }
}

int main(int argc, char *argv[]){

   int f_count = 0;
   char* files[argc];
   std::string regex;
   bool e_regex = true;


   for (int i = 1; i < argc; i++){
      if (e_regex){
         e_regex = false;
         regex = argv[i];
      } else {
         files[f_count] = argv[i];
         f_count++;
      }
   }

   if (f_count == 0){
      std::string filename = "";

      processFile(std::cin, regex, filename);
   } else if (f_count == 1){
      std::ifstream f {files[0]};
      std::string filename = "";

      processFile(f, regex, filename);
   } else {
      for (int x = 0; x < f_count;  x++){
         std::ifstream f {files[x]};
         std::string filename = "";

         processFile(f, regex, filename);
      }
   }
   return (0);
}

