#include <iostream>

int* getcount(std::istream &f);

